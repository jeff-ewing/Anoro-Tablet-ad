(function() {
    var xtrtrkr = document.createElement('script');
    xtrtrkr.type = 'text/javascript';
	if(document.location.href.toLowerCase().indexOf('neostaging')<0)
		xtrtrkr.src = ('https:' == document.location.protocol ? 'https://secure.tagify.diageo.com' : 'http://tagify.diageo.com') + '/xtrtrkr.js';
    else
		xtrtrkr.src = ('https:' == document.location.protocol ? 'https://secure.neostaging.tagify.diageo.com' : 'http://neostaging.tagify.diageo.com') + '/xtrtrkr.js';
	var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(xtrtrkr, s);
})();