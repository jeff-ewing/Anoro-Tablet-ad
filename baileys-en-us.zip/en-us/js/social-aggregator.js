// JavaScript Document

function socialAggregator( options ){
	
	this.opts = ( options || {} );
	this.layout = ['f-sm','f-sm','i-lg','i-lg','t-sm','i-sm','t-sm','f-sm','f-lg'];
	
}
socialAggregator.prototype = {
	init : function(){
		
		
		
		//var URL = 'json/facebook.json';
		var URL = 'json/instagram.json';
		$.getJSON( URL, function( data ) {
			//console.log('data => ' + data.albums.data.length) // facebook
			console.log('data => ' + data.data[0].images.standard_resolution.url) // instagram
		})
		
	}
}