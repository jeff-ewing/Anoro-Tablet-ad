//filter scroll
$(function(){
	var $filter = $('#filter')
	$(window).scroll(function(){
		console.log($(window).scrollTop());
		if($(window).scrollTop() >= 800){
	        $filter.addClass("fixed");
	    }
	    else{
	        $filter.removeClass("fixed");
	    }
	});
	//set filter position when page init
	if($(window).scrollTop() >= 800){
        $filter.addClass("fixed");
    }
	//fix the ancher offset
	$(".ancherFix").click(function(){$filter.addClass("fixed");return true;});
});

//filler recipes_hub
$(function(){
	$('.recipes_hub a.item .special').each(function(){
		$(this).css({
		height:$(this).height(),
		marginTop:-($(this).height()/2)
		});
	});
});

// module nav switch
$(function(){
	var moduleSlide = function(controllers, contents){		
		controllers.each(function(index,element){
			$(element).bind('click',function(){
				controllers.removeClass('current');
				controllers.next('span').removeClass('arrow');
				contents.removeClass('current');
				$(this).addClass('current');
				$(this).next('span').addClass('arrow')
				$(contents[index]).addClass('current');
				//trigger filter click event
				$(contents[index]).find("a.current").removeClass("current").trigger('click');
				return false;
			});
		});
	};

	moduleSlide($(".select_type a"),$(".sort_list"));

});

// story
$(function(){
	var $btn=$('.story span a');
	var $content =$('.story .info');
	//open the collapse when url has "#story"
	if(window.location.hash == "#story"){
		$content.show();
		$btn.addClass('collapse');
		$(this).prev().text($("#colHid").val());
		//fix the navigation
		$('#filter').addClass("fixed");
	}
	$btn.bind("click",function(){
		if($content.is(":visible")){
			$content.hide();
			$btn.removeClass('collapse');
			$(this).prev().text($("#expHid").val());
		}
		else{
			$content.show();
			$btn.addClass('collapse');
			$(this).prev().text($("#colHid").val());
		}
	})
});

//input 
$(function(){
	// checkbox
    $('.checkbox').bind("click",function(){
    	var selected = $(this).hasClass('selected');
        if (selected) {
        	$(this).removeClass('selected');
        } else {
           $(this).addClass('selected');
        }
    //radio
        var radio = $(this).hasClass('radio');
        if (radio) {
        	$(this).parent().siblings().find('.checkbox').removeClass('selected');
        } 
    });
});

//recipe detail height fix
$(function(){
	$(".recipes_detail .method .left_prepare ul:last").css("margin-bottom","0px");
	$(".recipes_detail .method .right_mix ol li:last").css("margin-bottom","0px");
});

// resize  all page img size
$(function(){
	var resizeHeight = function(objConHeight,objHeight){
		objHeight.height(objConHeight.height());
	}
	//resize list
	resizeHeight($(".product_original .obj_con"),$(".product_original .obj img"));
	resizeHeight($(".product_con .w_300"),$(".product_con .w_620 img"));
	resizeHeight($(".serving .impress .obj_con"),$(".serving .impress .obj img"));
	resizeHeight($(".news .flavour .obj_con"),$(".news .flavour .obj img"));
	resizeHeight($(".campaign_describe .obj_con"),$(".campaign_describe .obj img"));
	resizeHeight($(".termsContent .obj_con"),$(".termsContent .obj img"));
	resizeHeight($(".awards .part_4 .obj_con"),$(".awards .part_4 .obj img"));
	//set vertical middle in luxe page
	$(".luxeCon .obj_con").each(function(){
		var objHeight = $(this).height();
		$(this).css("margin-top","-" +((objHeight + 50)/2) + "px");
	});
});

function socialToolButtons(){
	this.opts = {
		title : $('meta[property="og:title"]').attr('content'),
		url : $('meta[property="og:url"]').attr('content'),
		image : $('meta[property="og:image"]').attr('content'),
		desc : $('meta[property="og:description"]').attr('content')	
	}
}

socialToolButtons.prototype = {
	init : function(){
		this.facebook();
		this.twitter();
		this.pinterest();
	},
	
	facebook : function(){
		var _this = this
		$('.ico.facebook.facebookShare').click(function(){
				window.open('http://www.facebook.com/sharer.php?u='+ _this.opts.url+'' ,'facebookshare','toolbar=0,status=0,height=436,width=650,scrollbars=yes,resizable=yes')
			})
	},
	
	twitter : function(){
		var _this = this
		$(".ico.twitter.twitterShare").click(function(){
             window.open("https://twitter.com/share?url=" + _this.opts.url + "&text="+_this.opts.desc+"" , "twittershare", "toolbar=0,status=0,height=436,width=650,scrollbars=yes,resizable=yes");
                                    });
	},
	
	pinterest : function(){
		var _this = this;
		$('.ico.pinterest').click(function(){
				window.open('http://www.pinterest.com/pin/create/button/?url=' + _this.opts.url + '&amp;media=' + _this.opts.image +'&amp;description=' + _this.opts.desc+'' ,'pinterestshare','toolbar=0,status=0,height=436,width=650,scrollbars=yes,resizable=yes')
			})
	}
}
