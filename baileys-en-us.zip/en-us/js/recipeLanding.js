$(function(){
  var $container = $('.imgcontainer');
  //use the url hash as the default filter
  var initFilter = "";
  
  //onload if hash equals this value, show that part of the navigation
	var $optionSelects = $('.select_type');
	var $optionSelectLinks = $optionSelects.find('a');
	if(window.location.hash){
		var thehash = window.location.hash;
		function objectconverter(a){
			var objectconverted = {};
			for(var i=0;i<a.length;i++){
				objectconverted[a[i]]='';
			}
			return objectconverted;
		}
		if( thehash in objectconverter(['#original', '#vanilla', '#caramel', '#hazelnut', '#coffee', '#choc-cherry']) ){
			$optionSelectLinks.removeClass('current');
			$optionSelectLinks.next('span').removeClass('arrow');
			$('.recipe-flavors').addClass('current');
			$('.recipe-flavors').next('span').addClass('arrow');
			
			$('.by_type_drink').removeClass('current');
			$('.by_type_flavor').addClass('current');
		}
		else if( thehash in objectconverter(['#stpatricksday','#bday','#brunch','#gno','#snow', '#wholidays']) ){
			$optionSelectLinks.removeClass('current');
			$optionSelectLinks.next('span').removeClass('arrow');
			$('.recipe-occasions').addClass('current');
			$('.recipe-occasions').next('span').addClass('arrow');
			
			$('.by_type_occaisions').addClass('current');
			$('.by_type_drink').removeClass('current');
			$('.by_type_flavor').removeClass('current');
		}
	}
	
  if(window.location.hash) initFilter =  window.location.hash.replace('#','.');
  //init isotope
  $container.isotope({
    masonry: {
	  columnWidth: 252
    },
    filter: initFilter,
    getSortData : {
      // sort function
      number : function ( $elem ) {
        return parseInt( $elem.find('.number').text(), 10);
      }
    },
    sortBy : 'number'
  });
  var $optionSets = $('.option-set'),
      $optionLinks = $optionSets.find('a');
  //set current link
  if(window.location.hash){ 
  	$optionLinks.removeClass('current'); 
  	$optionLinks.filter("a[filter='"+ initFilter +"']").addClass('current');
  }
  //banding click event
  $optionLinks.live('click',function(){
    var $this = $(this);
    //don't proceed if already selected
    if ( $this.hasClass('current') ) {
      return false;
    }
    var $optionSet = $this.parents('.option-set');
    $optionSet.find('.current').removeClass('current');
    $this.addClass('current');
    // make option object dynamically, i.e. { filter: '.my-filter-class' }
    var options = {filter: $this.attr('filter')},
        key = $optionSet.attr('data-option-key'),
        value = $this.attr('data-option-value');
    // parse 'false' as false boolean
    value = value === 'false' ? false : value;
    options[ key ] = value;
    $container.isotope( options );
    //set URL hash
    window.location.hash = $this.attr('filter').substring(1);
    return false;
  });
});