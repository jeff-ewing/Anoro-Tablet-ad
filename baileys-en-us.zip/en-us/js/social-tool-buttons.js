function socialToolButtons(){
	this.opts = {
		title : $('meta[property="og:title"]').attr('content'),
		url : $('meta[property="og:url"]').attr('content'),
		image : $('meta[property="og:image"]').attr('content'),
		desc : $('meta[property="og:description"]').attr('content')	
	}
}

socialToolButtons.prototype = {
	init : function(){
		this.facebook();
		this.twitter();
		this.pinterest();
	},
	
	facebook : function(){
		var _this = this
		$('.ico.facebook.facebookShare').click(function(){
				window.open('http://www.facebook.com/sharer.php?u='+ _this.opts.url+'' ,'facebookshare','toolbar=0,status=0,height=436,width=650,scrollbars=yes,resizable=yes');
				return false;
			})
	},
	
	twitter : function(){
		var _this = this
		$(".ico.twitter.twitterShare").click(function(){
             window.open("https://twitter.com/share?url=" + _this.opts.url + "&text="+_this.opts.desc+"" , "twittershare", "toolbar=0,status=0,height=436,width=650,scrollbars=yes,resizable=yes");
			 return false;
                                    });
	},
	
	pinterest : function(){
		var _this = this;
		$('.ico.pinterest').click(function(){
				
				window.open('http://www.pinterest.com/pin/create/button/?url=' + _this.opts.url + '&amp;media=' + _this.opts.image +'&amp;description=' + _this.opts.desc+'' ,'pinterestshare','toolbar=0,status=0,height=436,width=650,scrollbars=yes,resizable=yes');
				return false
			})
	}
}