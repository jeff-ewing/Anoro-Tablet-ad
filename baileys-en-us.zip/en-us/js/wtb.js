$( document ).ready(function() {
		
		$('.cream').hoverIntent(function() {
				$(this).find('#wtb_sub').fadeToggle("1000"); 
			});
	});